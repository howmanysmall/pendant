const consoleLog = console.log;
consoleLog("Hello!");
